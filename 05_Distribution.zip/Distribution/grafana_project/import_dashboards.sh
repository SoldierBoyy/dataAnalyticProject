#!/bin/bash

# Ожидание доступности Grafana API
until curl -sSf "http://localhost:3000/api/health"; do
  sleep 1
done

# Импорт каждого JSON файла дашборда, соответствующего шаблону "dashboard_*.json"
for dashboard_file in /tmp/dashboards/dashboard_*.json; do
  if [ -f "$dashboard_file" ]; then
    dashboard_name=$(basename "$dashboard_file" .json)
    dashboard_name=${dashboard_name#"dashboard_"}  # Извлечение имени дашборда из имени файла
    echo "Импорт дашборда: $dashboard_name"
    
    # Отправка запроса на импорт дашборда в Grafana
    curl -X POST \
      -H "Content-Type: application/json" \
      -d "@$dashboard_file" \
      "http://localhost:3000/api/dashboards/db"
      
    echo "Дашборд '$dashboard_name' импортирован."
  fi
done

echo "Импорт дашбордов завершен."

